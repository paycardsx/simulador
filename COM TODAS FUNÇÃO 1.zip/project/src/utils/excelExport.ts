import * as XLSX from 'xlsx';
import { SimulationRecord } from '../types/types';

export const exportToExcel = (historico: SimulationRecord[]) => {
  const workbook = XLSX.utils.book_new();
  
  // Transform data for Excel
  const data = historico.map(record => ({
    'Data': record.data,
    'Tipo': record.tipo === 'cobrar' ? 'Cobrança' : 'Recebimento',
    'Valor Principal': record.valorPrincipal,
    'Parcelamento': `${record.parcelamento}x`,
    'Taxa Aplicada': `${record.taxaAplicada}%`,
    'Taxa de Custo': `${record.taxaDeCusto}%`,
    'Lucro': record.lucro,
    'Valor da Parcela': record.valorParcela,
    'Valor a Receber': record.valorReceber,
    'Juros': record.juros,
    'Valor a Passar': record.valorPassar
  }));

  const worksheet = XLSX.utils.json_to_sheet(data);

  // Set column widths
  const columnWidths = [
    { wch: 12 },  // Data
    { wch: 12 },  // Tipo
    { wch: 15 },  // Valor Principal
    { wch: 12 },  // Parcelamento
    { wch: 12 },  // Taxa Aplicada
    { wch: 12 },  // Taxa de Custo
    { wch: 15 },  // Lucro
    { wch: 15 },  // Valor da Parcela
    { wch: 15 },  // Valor a Receber
    { wch: 15 },  // Juros
    { wch: 15 }   // Valor a Passar
  ];
  worksheet['!cols'] = columnWidths;

  XLSX.utils.book_append_sheet(workbook, worksheet, 'Histórico');
  
  // Generate Excel file
  XLSX.writeFile(workbook, 'historico_financeiro.xlsx');
};