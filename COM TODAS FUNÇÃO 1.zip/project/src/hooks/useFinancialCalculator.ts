import { useState, useCallback } from 'react';
import { SimulationRecord, CalculationResult } from '../types/types';

const DEFAULT_TAXAS = [
  7.70, 9.00, 9.60, 10.20, 10.70, 11.30, 11.75, 12.30,
  13.00, 13.50, 14.10, 14.60, 15.70, 15.70, 16.30, 16.80,
  17.40, 18.00
];

const DEFAULT_TAXAS_DE_CUSTO = [
  4.5, 5.0, 5.6, 6.2, 6.7, 7.3, 7.75, 8.3, 8.85, 9.35,
  10.0, 10.5, 12.5, 12.7, 13.3, 13.8, 14.4, 15.0
];

const UNDO_TIMEOUT = 10000; // 10 seconds in milliseconds

interface DeletedItem {
  item: SimulationRecord;
  originalIndex: number;
  timer: NodeJS.Timeout;
  timeLeft: number;
}

export const useFinancialCalculator = () => {
  const [modoCobrar, setModoCobrar] = useState(true);
  const [historico, setHistorico] = useState<SimulationRecord[]>([]);
  const [deletedItems, setDeletedItems] = useState<Map<string, DeletedItem>>(new Map());
  const [acessoLiberado, setAcessoLiberado] = useState(false);
  const [taxas, setTaxas] = useState<number[]>(DEFAULT_TAXAS);
  const [taxasDeCusto, setTaxasDeCusto] = useState<number[]>(DEFAULT_TAXAS_DE_CUSTO);

  const calcular = (valor: number, parcelas: number): CalculationResult | null => {
    if (isNaN(valor) || valor < 100) return null;

    const taxaAplicada = taxas[parcelas - 1];
    const taxaDeCusto = taxasDeCusto[parcelas - 1];
    const lucro = taxaAplicada - taxaDeCusto;

    const valorPassar = modoCobrar
      ? valor - (valor * (taxaAplicada / 100))
      : (100 * valor) / (100 - taxaAplicada);

    const lucroEmDinheiro = (modoCobrar
      ? valor * (lucro / 100)
      : valorPassar * (lucro / 100)
    ).toLocaleString("pt-BR", { style: "currency", currency: "BRL" });

    const juros = modoCobrar ? valor - valorPassar : valorPassar - valor;
    const valorParcela = (parcelas > 1 
      ? (modoCobrar ? valor / parcelas : valorPassar / parcelas)
      : modoCobrar ? valor : valorPassar
    ).toLocaleString("pt-BR", { style: "currency", currency: "BRL" });

    return {
      parcelamento: parcelas,
      taxaAplicada,
      taxaDeCusto,
      lucro: lucroEmDinheiro,
      valorParcela,
      valorReceber: valor.toLocaleString("pt-BR", { style: "currency", currency: "BRL" }),
      juros: (juros > 0 ? "-" : "") + juros.toLocaleString("pt-BR", { style: "currency", currency: "BRL" }),
      valorPassar: valorPassar.toLocaleString("pt-BR", { style: "currency", currency: "BRL" }),
      bandeira: 'master-visa'
    };
  };

  const registrarSimulacao = (resultado: CalculationResult) => {
    const novaSimulacao: SimulationRecord = {
      id: Date.now().toString(),
      data: new Date().toLocaleDateString("pt-BR"),
      parcelamento: resultado.parcelamento.toString(),
      taxaAplicada: resultado.taxaAplicada.toString(),
      taxaDeCusto: resultado.taxaDeCusto.toString(),
      lucro: resultado.lucro,
      valorParcela: resultado.valorParcela,
      valorReceber: resultado.valorReceber,
      valorPassar: resultado.valorPassar,
      juros: resultado.juros,
      valorPrincipal: modoCobrar ? resultado.valorReceber : resultado.valorPassar,
      tipo: modoCobrar ? 'cobrar' : 'receber'
    };

    setHistorico(prev => [novaSimulacao, ...prev]);
  };

  const removerItem = (id: string) => {
    const index = historico.findIndex(item => item.id === id);
    if (index === -1) return;

    const [removedItem] = historico.splice(index, 1);
    setHistorico([...historico]);

    // Clear existing timer if item was already deleted
    if (deletedItems.has(id)) {
      clearTimeout(deletedItems.get(id)!.timer);
    }

    // Create new timer for this deletion
    const timer = setTimeout(() => {
      setDeletedItems(prev => {
        const next = new Map(prev);
        next.delete(id);
        return next;
      });
    }, UNDO_TIMEOUT);

    // Update deleted items
    setDeletedItems(prev => {
      const next = new Map(prev);
      next.set(id, {
        item: removedItem,
        originalIndex: index,
        timer,
        timeLeft: UNDO_TIMEOUT / 1000
      });
      return next;
    });

    // Start countdown
    const countdownInterval = setInterval(() => {
      setDeletedItems(prev => {
        const item = prev.get(id);
        if (!item) {
          clearInterval(countdownInterval);
          return prev;
        }

        const next = new Map(prev);
        next.set(id, {
          ...item,
          timeLeft: Math.max(0, item.timeLeft - 1)
        });
        return next;
      });
    }, 1000);
  };

  const desfazerExclusao = (id: string) => {
    const deletedItem = deletedItems.get(id);
    if (!deletedItem) return;

    // Clear the deletion timer
    clearTimeout(deletedItem.timer);

    // Restore the item to its original position
    const newHistorico = [...historico];
    newHistorico.splice(deletedItem.originalIndex, 0, deletedItem.item);
    setHistorico(newHistorico);

    // Remove from deleted items
    setDeletedItems(prev => {
      const next = new Map(prev);
      next.delete(id);
      return next;
    });
  };

  const login = (username: string, password: string): boolean => {
    if (username === "adm" && password === "1234") {
      setAcessoLiberado(true);
      return true;
    }
    return false;
  };

  const logout = () => {
    setAcessoLiberado(false);
  };

  const atualizarTaxas = (novasTaxas: number[], novasTaxasDeCusto: number[]) => {
    setTaxas(novasTaxas);
    setTaxasDeCusto(novasTaxasDeCusto);
  };

  return {
    modoCobrar,
    setModoCobrar,
    acessoLiberado,
    historico,
    deletedItems,
    taxas,
    taxasDeCusto,
    calcular,
    registrarSimulacao,
    removerItem,
    desfazerExclusao,
    login,
    logout,
    atualizarTaxas
  };
};