import React from 'react';
import { Calculator as CalculatorIcon, LogOut, Download, Settings, ArrowLeft } from 'lucide-react';
import { exportToExcel } from '../utils/excelExport';
import { SimulationRecord } from '../types/types';

interface HeaderProps {
  modoCobrar: boolean;
  setModoCobrar: (mode: boolean) => void;
  acessoLiberado: boolean;
  onLogout: () => void;
  historico: SimulationRecord[];
  onToggleSettings: () => void;
  showSettings: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  modoCobrar,
  setModoCobrar,
  acessoLiberado,
  onLogout,
  historico,
  onToggleSettings,
  showSettings
}) => {
  const handleExport = () => {
    if (historico && historico.length > 0) {
      exportToExcel(historico);
    }
  };

  return (
    <div className="flex flex-col md:flex-row justify-between items-center bg-white p-6 rounded-lg shadow-md">
      <div className="flex items-center space-x-3 mb-4 md:mb-0">
        <CalculatorIcon className="h-8 w-8 text-blue-600" />
        <h1 className="text-2xl font-bold text-gray-800">Calculadora Financeira</h1>
      </div>
      
      <div className="flex flex-wrap gap-4 items-center">
        {acessoLiberado && (
          showSettings ? (
            <button
              onClick={onToggleSettings}
              className="flex items-center space-x-2 px-4 py-2 bg-gray-100 text-gray-700 hover:bg-gray-200 rounded-md transition-colors"
            >
              <ArrowLeft size={20} />
              <span>Voltar ao Simulador</span>
            </button>
          ) : (
            <button
              onClick={onToggleSettings}
              className="flex items-center space-x-2 px-4 py-2 bg-gray-100 text-gray-700 hover:bg-gray-200 rounded-md transition-colors"
            >
              <Settings size={20} />
              <span>Configurações</span>
            </button>
          )
        )}

        {!showSettings && (
          <div className="flex space-x-2">
            <button
              onClick={() => setModoCobrar(true)}
              className={`px-4 py-2 rounded-md transition-colors ${
                modoCobrar
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              Modo Cobrar
            </button>
            <button
              onClick={() => setModoCobrar(false)}
              className={`px-4 py-2 rounded-md transition-colors ${
                !modoCobrar
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              Modo Receber
            </button>
          </div>
        )}
        
        {acessoLiberado && (
          <div className="flex space-x-2">
            <button
              onClick={handleExport}
              className="flex items-center space-x-2 px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors"
              disabled={!historico || historico.length === 0}
            >
              <Download size={20} />
              <span>Exportar Excel</span>
            </button>
            <button
              onClick={onLogout}
              className="flex items-center space-x-2 px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 transition-colors"
            >
              <LogOut size={20} />
              <span>Sair</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};