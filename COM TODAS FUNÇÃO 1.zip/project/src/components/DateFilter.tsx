import React from 'react';
import { Calendar } from 'lucide-react';

type DateRange = 'today' | 'week' | '30days' | '90days' | 'all' | 'custom';

interface DateFilterProps {
  selectedRange: DateRange;
  onRangeChange: (range: DateRange) => void;
  customDateRange: { start: string; end: string };
  onCustomDateChange: (start: string, end: string) => void;
}

export const DateFilter: React.FC<DateFilterProps> = ({
  selectedRange,
  onRangeChange,
  customDateRange,
  onCustomDateChange,
}) => {
  return (
    <div className="flex flex-col sm:flex-row items-center gap-4 mb-4">
      <div className="flex items-center space-x-2 text-gray-600">
        <Calendar size={20} />
        <span className="font-medium">Filtrar por período:</span>
      </div>
      
      <div className="flex flex-wrap gap-2">
        <button
          onClick={() => onRangeChange('today')}
          className={`px-3 py-1 rounded-md text-sm transition-colors ${
            selectedRange === 'today'
              ? 'bg-blue-600 text-white'
              : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
          }`}
        >
          Hoje
        </button>
        
        <button
          onClick={() => onRangeChange('week')}
          className={`px-3 py-1 rounded-md text-sm transition-colors ${
            selectedRange === 'week'
              ? 'bg-blue-600 text-white'
              : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
          }`}
        >
          Última Semana
        </button>
        
        <button
          onClick={() => onRangeChange('30days')}
          className={`px-3 py-1 rounded-md text-sm transition-colors ${
            selectedRange === '30days'
              ? 'bg-blue-600 text-white'
              : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
          }`}
        >
          30 Dias
        </button>
        
        <button
          onClick={() => onRangeChange('90days')}
          className={`px-3 py-1 rounded-md text-sm transition-colors ${
            selectedRange === '90days'
              ? 'bg-blue-600 text-white'
              : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
          }`}
        >
          90 Dias
        </button>
        
        <button
          onClick={() => onRangeChange('all')}
          className={`px-3 py-1 rounded-md text-sm transition-colors ${
            selectedRange === 'all'
              ? 'bg-blue-600 text-white'
              : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
          }`}
        >
          Todo Período
        </button>
        
        <button
          onClick={() => onRangeChange('custom')}
          className={`px-3 py-1 rounded-md text-sm transition-colors ${
            selectedRange === 'custom'
              ? 'bg-blue-600 text-white'
              : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
          }`}
        >
          Personalizado
        </button>
      </div>

      {selectedRange === 'custom' && (
        <div className="flex items-center space-x-2">
          <input
            type="date"
            value={customDateRange.start}
            onChange={(e) => onCustomDateChange(e.target.value, customDateRange.end)}
            className="px-2 py-1 rounded-md border border-gray-300 text-sm"
          />
          <span>até</span>
          <input
            type="date"
            value={customDateRange.end}
            onChange={(e) => onCustomDateChange(customDateRange.start, e.target.value)}
            className="px-2 py-1 rounded-md border border-gray-300 text-sm"
          />
        </div>
      )}
    </div>
  );
};