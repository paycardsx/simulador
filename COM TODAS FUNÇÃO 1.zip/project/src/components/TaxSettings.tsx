import React, { useState } from 'react';
import { Save, Info, AlertCircle } from 'lucide-react';
import { Tooltip } from './Tooltip';

interface TaxSettingsProps {
  taxas: number[];
  taxasDeCusto: number[];
  onSave: (newTaxas: number[], newTaxasDeCusto: number[]) => void;
}

export const TaxSettings: React.FC<TaxSettingsProps> = ({
  taxas,
  taxasDeCusto,
  onSave,
}) => {
  const [newTaxas, setNewTaxas] = useState<number[]>(taxas);
  const [newTaxasDeCusto, setNewTaxasDeCusto] = useState<number[]>(taxasDeCusto);
  const [error, setError] = useState<string>('');

  const handleTaxaChange = (index: number, value: string, isCusto: boolean) => {
    const numValue = parseFloat(value);
    if (isNaN(numValue)) return;

    if (isCusto) {
      const updatedTaxas = [...newTaxasDeCusto];
      updatedTaxas[index] = numValue;
      setNewTaxasDeCusto(updatedTaxas);
    } else {
      const updatedTaxas = [...newTaxas];
      updatedTaxas[index] = numValue;
      setNewTaxas(updatedTaxas);
    }
  };

  const validateTaxas = (): boolean => {
    for (let i = 0; i < newTaxas.length; i++) {
      if (newTaxas[i] <= newTaxasDeCusto[i]) {
        setError(`Erro na parcela ${i + 1}x: Taxa aplicada deve ser maior que taxa de custo`);
        return false;
      }
    }
    setError('');
    return true;
  };

  const handleSave = () => {
    if (validateTaxas()) {
      onSave(newTaxas, newTaxasDeCusto);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-bold text-gray-800">Configuração de Taxas</h2>
        <button
          onClick={handleSave}
          className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
        >
          <Save size={20} />
          <span>Salvar Alterações</span>
        </button>
      </div>

      {error && (
        <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-md flex items-center space-x-2 text-red-600">
          <AlertCircle size={20} />
          <span>{error}</span>
        </div>
      )}

      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="bg-gray-50">
              <th className="px-4 py-2 text-left text-sm font-medium text-gray-600">Parcelas</th>
              <th className="px-4 py-2 text-left text-sm font-medium text-gray-600">
                <div className="flex items-center space-x-2">
                  <span>Taxa Aplicada (%)</span>
                  <Tooltip content="Taxa cobrada do cliente final">
                    <Info size={16} className="text-gray-400 cursor-help" />
                  </Tooltip>
                </div>
              </th>
              <th className="px-4 py-2 text-left text-sm font-medium text-gray-600">
                <div className="flex items-center space-x-2">
                  <span>Taxa de Custo (%)</span>
                  <Tooltip content="Taxa cobrada pela operadora">
                    <Info size={16} className="text-gray-400 cursor-help" />
                  </Tooltip>
                </div>
              </th>
              <th className="px-4 py-2 text-left text-sm font-medium text-gray-600">Lucro (%)</th>
            </tr>
          </thead>
          <tbody>
            {newTaxas.map((taxa, index) => (
              <tr key={index} className="border-t border-gray-100">
                <td className="px-4 py-2 text-sm text-gray-600">{index + 1}x</td>
                <td className="px-4 py-2">
                  <input
                    type="number"
                    step="0.01"
                    value={taxa}
                    onChange={(e) => handleTaxaChange(index, e.target.value, false)}
                    className="w-24 px-2 py-1 border border-gray-300 rounded-md focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                  />
                </td>
                <td className="px-4 py-2">
                  <input
                    type="number"
                    step="0.01"
                    value={newTaxasDeCusto[index]}
                    onChange={(e) => handleTaxaChange(index, e.target.value, true)}
                    className="w-24 px-2 py-1 border border-gray-300 rounded-md focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                  />
                </td>
                <td className="px-4 py-2 text-sm">
                  <span className={taxa - newTaxasDeCusto[index] < 0 ? 'text-red-600' : 'text-green-600'}>
                    {(taxa - newTaxasDeCusto[index]).toFixed(2)}%
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}