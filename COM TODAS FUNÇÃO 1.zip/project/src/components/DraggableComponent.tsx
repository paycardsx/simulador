import React, { useRef, useState } from 'react';
import { Move } from 'lucide-react';

interface ComponentStyle {
  width: string;
  height: string;
  position: 'static' | 'relative' | 'absolute' | 'fixed';
  top?: string;
  left?: string;
  padding: string;
  margin: string;
  backgroundColor?: string;
}

interface DraggableComponentProps {
  id: string;
  style: ComponentStyle;
  isDevMode: boolean;
  children: React.ReactNode;
  onStyleChange: (style: ComponentStyle) => void;
}

export const DraggableComponent: React.FC<DraggableComponentProps> = ({
  id,
  style,
  isDevMode,
  children,
  onStyleChange
}) => {
  const componentRef = useRef<HTMLDivElement>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });

  const handleMouseDown = (e: React.MouseEvent) => {
    if (!isDevMode) return;
    
    setIsDragging(true);
    setDragStart({
      x: e.clientX - (componentRef.current?.offsetLeft || 0),
      y: e.clientY - (componentRef.current?.offsetTop || 0)
    });
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging || !isDevMode) return;

    const newLeft = `${e.clientX - dragStart.x}px`;
    const newTop = `${e.clientY - dragStart.y}px`;

    onStyleChange({
      ...style,
      position: 'absolute',
      left: newLeft,
      top: newTop
    });
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  return (
    <div
      ref={componentRef}
      style={{
        ...style,
        cursor: isDevMode ? 'move' : 'default',
        transition: isDragging ? 'none' : 'all 0.2s ease',
        outline: isDevMode ? '1px dashed #cbd5e0' : 'none'
      }}
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseUp}
      className="relative group"
    >
      {isDevMode && (
        <div className="absolute -top-3 -left-3 bg-white p-1 rounded-full shadow-md opacity-0 group-hover:opacity-100 transition-opacity">
          <Move size={16} className="text-gray-600" />
        </div>
      )}
      {children}
    </div>
  );
};