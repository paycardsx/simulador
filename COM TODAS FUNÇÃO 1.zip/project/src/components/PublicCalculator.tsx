import React, { useState } from 'react';
import { Calculator as CalculatorIcon, Share2, Check, Copy } from 'lucide-react';
import { CalculationResult } from '../types/types';

interface PublicCalculatorProps {
  calcular: (valor: number, parcelas: number) => CalculationResult | null;
  taxas: number[];
}

export const PublicCalculator: React.FC<PublicCalculatorProps> = ({ calcular, taxas }) => {
  const [valor, setValor] = useState('5.000,00');
  const [parcelas, setParcelas] = useState('12');
  const [modoCobrar, setModoCobrar] = useState(true);
  const [resultado, setResultado] = useState<CalculationResult | null>(null);
  const [copied, setCopied] = useState(false);

  const formatarValor = (input: string) => {
    const numero = input.replace(/\D/g, '');
    const valorFormatado = (Number(numero) / 100).toFixed(2);
    return valorFormatado.replace('.', ',').replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');
  };

  const handleValorChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setValor(formatarValor(e.target.value));
  };

  const handleCalcular = () => {
    const valorNumerico = parseFloat(valor.replace(/\./g, '').replace(',', '.'));
    const parcelasNumerico = parseInt(parcelas);
    const result = calcular(valorNumerico, parcelasNumerico);
    setResultado(result);
  };

  const copyToClipboard = () => {
    const url = `${window.location.origin}/public`;
    navigator.clipboard.writeText(url).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  return (
    <div className="min-h-screen bg-gray-100 p-4 md:p-8">
      <div className="max-w-2xl mx-auto">
        <div className="bg-white rounded-lg shadow-lg p-6">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 mb-6">
            <div className="flex items-center space-x-3">
              <CalculatorIcon className="h-8 w-8 text-blue-600" />
              <h1 className="text-2xl font-bold text-gray-800">Simulador Financeiro</h1>
            </div>
            <button
              onClick={copyToClipboard}
              className={`flex items-center space-x-2 px-4 py-2 rounded-md transition-all duration-200 ${
                copied 
                  ? 'bg-green-100 text-green-700'
                  : 'bg-blue-50 text-blue-600 hover:bg-blue-100'
              }`}
            >
              {copied ? (
                <>
                  <Check size={20} />
                  <span>Link Copiado!</span>
                </>
              ) : (
                <>
                  <Share2 size={20} />
                  <span>Compartilhar Calculadora</span>
                </>
              )}
            </button>
          </div>

          <div className="flex space-x-2 mb-6">
            <button
              onClick={() => setModoCobrar(true)}
              className={`flex-1 px-4 py-2 rounded-md transition-colors ${
                modoCobrar
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              Modo Cobrar
            </button>
            <button
              onClick={() => setModoCobrar(false)}
              className={`flex-1 px-4 py-2 rounded-md transition-colors ${
                !modoCobrar
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              Modo Receber
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Valor a {modoCobrar ? "cobrar" : "receber"}
              </label>
              <div className="relative">
                <span className="absolute left-3 top-2 text-gray-500">R$</span>
                <input
                  type="text"
                  value={valor}
                  onChange={handleValorChange}
                  className="block w-full pl-10 pr-3 py-2 rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Parcelamento
              </label>
              <select
                value={parcelas}
                onChange={(e) => setParcelas(e.target.value)}
                className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              >
                {[...Array(18)].map((_, i) => (
                  <option key={i + 1} value={i + 1}>{i + 1}x</option>
                ))}
              </select>
            </div>
          </div>

          <button
            onClick={handleCalcular}
            className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 mb-6"
          >
            Calcular
          </button>

          {resultado && (
            <div className="bg-gray-50 rounded-lg p-4 space-y-2">
              <h3 className="font-semibold text-lg text-gray-800 mb-3">Resultado da Simulação</h3>
              
              <div className="grid grid-cols-2 gap-2">
                <div className="text-sm text-gray-600">Parcelamento:</div>
                <div className="text-sm font-medium">{resultado.parcelamento}x</div>
                
                <div className="text-sm text-gray-600">Taxa aplicada:</div>
                <div className="text-sm font-medium">{resultado.taxaAplicada}%</div>
                
                <div className="text-sm text-gray-600">Valor da Parcela:</div>
                <div className="text-sm font-medium text-green-600">
                  {resultado.valorParcela} {resultado.parcelamento > 1 ? `(${resultado.parcelamento}x)` : ''}
                </div>
                
                <div className="text-sm text-gray-600">
                  Valor que deseja {modoCobrar ? "cobrar" : "receber"}:
                </div>
                <div className="text-sm font-medium">{resultado.valorReceber}</div>
                
                <div className="text-sm text-gray-600">Juros:</div>
                <div className="text-sm font-medium text-red-600">{resultado.juros}</div>
                
                <div className="text-sm text-gray-600">
                  Valor a {modoCobrar ? "receber" : "passar na maquininha"}:
                </div>
                <div className="text-sm font-medium text-green-600">{resultado.valorPassar}</div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};