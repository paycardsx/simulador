import React, { useState } from 'react';
import { ChevronDown, ChevronUp, Trash2, ArrowUpCircle, ArrowDownCircle, Undo2, ChevronRight } from 'lucide-react';
import { SimulationRecord } from '../types/types';
import { OperationsSummaryContainer } from '../containers/OperationsSummaryContainer';

interface HistoryProps {
  historico: SimulationRecord[];
  deletedItems: Map<string, { item: SimulationRecord; timeLeft: number }>;
  onRemoverItem: (id: string) => void;
  onDesfazerExclusao: (id: string) => void;
}

export const History: React.FC<HistoryProps> = ({
  historico,
  deletedItems,
  onRemoverItem,
  onDesfazerExclusao
}) => {
  const [expandedItems, setExpandedItems] = useState<Record<string, boolean>>({});
  const [showAll, setShowAll] = useState(false);

  const toggleDetalhes = (id: string) => {
    setExpandedItems(prev => ({
      ...prev,
      [id]: !prev[id]
    }));
  };

  const displayedRecords = showAll ? historico : historico.slice(0, 5);

  return (
    <div className="space-y-4">
      <OperationsSummaryContainer historico={historico} />

      <div className="mt-6">
        {Array.from(deletedItems.entries()).map(([id, { item, timeLeft }]) => (
          <div key={`deleted-${id}`} className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-4 animate-fade-in">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <span className="text-yellow-600">Item excluído:</span>
                <span className="font-medium">{item.valorPrincipal}</span>
                <span className="text-sm text-gray-500">
                  {item.data} • {item.parcelamento}x
                </span>
              </div>
              <button
                onClick={() => onDesfazerExclusao(id)}
                className="flex items-center space-x-2 px-3 py-1 bg-yellow-100 text-yellow-700 rounded-md hover:bg-yellow-200 transition-colors"
              >
                <Undo2 size={18} />
                <span>Desfazer ({timeLeft}s)</span>
              </button>
            </div>
          </div>
        ))}

        {displayedRecords.map((simulacao) => {
          const id = simulacao.id;
          const isCobrar = simulacao.tipo === 'cobrar';
          
          return (
            <div key={id} className="bg-white rounded-lg shadow-sm border border-gray-200 hover:border-gray-300 transition-colors">
              <div className="flex items-center justify-between p-4">
                <div className="flex items-center space-x-4">
                  <span className={`p-2 rounded-full ${isCobrar ? 'bg-red-100 text-red-600' : 'bg-green-100 text-green-600'}`}>
                    {isCobrar ? <ArrowUpCircle size={20} /> : <ArrowDownCircle size={20} />}
                  </span>
                  <button
                    onClick={() => toggleDetalhes(id)}
                    className="flex items-center space-x-2 text-gray-700 hover:text-gray-900"
                  >
                    {expandedItems[id] ? <ChevronUp size={20} /> : <ChevronDown size={20} />}
                    <div>
                      <span className="font-medium">{simulacao.valorPrincipal}</span>
                      <span className="text-sm text-gray-500 ml-2">
                        {simulacao.data} • {simulacao.parcelamento}x
                      </span>
                    </div>
                  </button>
                </div>
                <button
                  onClick={() => onRemoverItem(id)}
                  className="text-gray-400 hover:text-red-500 transition-colors"
                >
                  <Trash2 size={20} />
                </button>
              </div>
              
              {expandedItems[id] && (
                <div className="px-4 pb-4 pt-2 border-t border-gray-100">
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div className="text-gray-600">Tipo:</div>
                    <div className={isCobrar ? 'text-red-600' : 'text-green-600'}>
                      {isCobrar ? 'Cobrança' : 'Recebimento'}
                    </div>
                    
                    <div className="text-gray-600">Parcelamento:</div>
                    <div>{simulacao.parcelamento}x</div>
                    
                    <div className="text-gray-600">Taxa aplicada:</div>
                    <div>{simulacao.taxaAplicada}%</div>
                    
                    <div className="text-gray-600">Taxa de custo:</div>
                    <div>{simulacao.taxaDeCusto}%</div>
                    
                    <div className="text-gray-600">Lucro:</div>
                    <div className="text-green-600">{simulacao.lucro}</div>
                    
                    <div className="text-gray-600">Valor da Parcela:</div>
                    <div>{simulacao.valorParcela}</div>
                    
                    <div className="text-gray-600">Valor {isCobrar ? 'cobrado' : 'recebido'}:</div>
                    <div>{simulacao.valorReceber}</div>
                    
                    <div className="text-gray-600">Juros:</div>
                    <div className="text-red-600">{simulacao.juros}</div>
                    
                    <div className="text-gray-600">
                      Valor {isCobrar ? 'recebido' : 'passado na maquininha'}:
                    </div>
                    <div className="text-green-600">{simulacao.valorPassar}</div>
                  </div>
                </div>
              )}
            </div>
          );
        })}

        {historico.length > 5 && (
          <button
            onClick={() => setShowAll(!showAll)}
            className="w-full flex items-center justify-center space-x-2 py-2 px-4 bg-gray-50 text-gray-600 rounded-lg hover:bg-gray-100 transition-colors"
          >
            <span>{showAll ? 'Mostrar Menos' : 'Ver Mais'}</span>
            <ChevronRight size={20} className={`transform transition-transform ${showAll ? 'rotate-90' : ''}`} />
          </button>
        )}
      </div>
    </div>
  );
};