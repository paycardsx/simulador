import React, { useState, useEffect } from 'react';
import { Settings, Save, Eye, EyeOff } from 'lucide-react';

interface ContainerStyle {
  width: string;
  height: string;
  position: 'static' | 'relative' | 'absolute' | 'fixed';
  top?: string;
  left?: string;
  padding: string;
  margin: string;
  backgroundColor?: string;
}

interface StyleConfig {
  [key: string]: ContainerStyle;
}

interface DeveloperModeProps {
  children: React.ReactNode;
  containers: string[];
}

export const DeveloperMode: React.FC<DeveloperModeProps> = ({ children, containers }) => {
  const [isDevMode, setIsDevMode] = useState(false);
  const [styles, setStyles] = useState<StyleConfig>({});
  const [selectedContainer, setSelectedContainer] = useState<string | null>(null);
  const [showGrid, setShowGrid] = useState(true);
  const [isDragging, setIsDragging] = useState(false);
  const [dragTarget, setDragTarget] = useState<string | null>(null);

  useEffect(() => {
    const defaultStyles: StyleConfig = containers.reduce((acc, id) => ({
      ...acc,
      [id]: {
        width: '100%',
        height: 'auto',
        position: 'relative',
        padding: '1.5rem',
        margin: '0',
        backgroundColor: '#ffffff'
      }
    }), {});

    setStyles(defaultStyles);
  }, [containers]);

  useEffect(() => {
    if (isDevMode) {
      containers.forEach(id => {
        const container = document.getElementById(id);
        if (container) {
          container.style.cursor = 'move';
          container.addEventListener('mousedown', handleMouseDown);
        }
      });
    }

    return () => {
      containers.forEach(id => {
        const container = document.getElementById(id);
        if (container) {
          container.style.cursor = 'default';
          container.removeEventListener('mousedown', handleMouseDown);
        }
      });
    };
  }, [isDevMode, containers]);

  const handleMouseDown = (e: MouseEvent) => {
    if (!isDevMode) return;
    const container = (e.target as HTMLElement).closest('[id]') as HTMLElement;
    if (!container || !containers.includes(container.id)) return;

    setIsDragging(true);
    setDragTarget(container.id);
    
    const handleMouseMove = (e: MouseEvent) => {
      if (!isDragging || !dragTarget) return;

      const container = document.getElementById(dragTarget);
      if (!container) return;

      const rect = container.getBoundingClientRect();
      const newLeft = e.clientX - rect.width / 2;
      const newTop = e.clientY - rect.height / 2;

      setStyles(prev => ({
        ...prev,
        [dragTarget]: {
          ...prev[dragTarget],
          position: 'absolute',
          left: `${newLeft}px`,
          top: `${newTop}px`
        }
      }));
    };

    const handleMouseUp = () => {
      setIsDragging(false);
      setDragTarget(null);
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };

    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);
  };

  const handleStyleChange = (
    containerId: string,
    property: keyof ContainerStyle,
    value: string
  ) => {
    setStyles(prev => ({
      ...prev,
      [containerId]: {
        ...prev[containerId],
        [property]: value
      }
    }));

    const container = document.getElementById(containerId);
    if (container) {
      container.style[property as any] = value;
    }
  };

  const exportStyles = () => {
    const styleString = JSON.stringify(styles, null, 2);
    const blob = new Blob([styleString], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'calculator-styles.json';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="relative">
      <button
        onClick={() => setIsDevMode(!isDevMode)}
        className="fixed bottom-4 right-4 z-50 p-3 bg-gray-900 text-white rounded-full shadow-lg hover:bg-gray-800 transition-colors"
      >
        <Settings size={24} />
      </button>

      {isDevMode && (
        <div className="fixed right-4 bottom-20 z-50 w-80 bg-white rounded-lg shadow-xl border border-gray-200">
          <div className="p-4 border-b border-gray-200">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-gray-800">Developer Mode</h2>
              <div className="flex items-center space-x-2">
                <button
                  onClick={() => setShowGrid(!showGrid)}
                  className="p-2 text-gray-600 hover:text-gray-900 transition-colors"
                  title={showGrid ? 'Hide Grid' : 'Show Grid'}
                >
                  {showGrid ? <Eye size={20} /> : <EyeOff size={20} />}
                </button>
                <button
                  onClick={exportStyles}
                  className="p-2 text-gray-600 hover:text-gray-900 transition-colors"
                  title="Export Styles"
                >
                  <Save size={20} />
                </button>
              </div>
            </div>

            <div className="flex flex-wrap gap-2">
              {containers.map(id => (
                <button
                  key={id}
                  onClick={() => setSelectedContainer(id)}
                  className={`px-3 py-1 rounded-md text-sm ${
                    selectedContainer === id
                      ? 'bg-blue-600 text-white'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  {id}
                </button>
              ))}
            </div>
          </div>

          {selectedContainer && styles[selectedContainer] && (
            <div className="p-4 space-y-4 max-h-[60vh] overflow-y-auto">
              <div className="space-y-2">
                <label className="block text-sm font-medium text-gray-700">Position</label>
                <select
                  value={styles[selectedContainer].position}
                  onChange={(e) => handleStyleChange(selectedContainer, 'position', e.target.value as any)}
                  className="w-full px-3 py-2 border rounded-md"
                >
                  <option value="static">Static</option>
                  <option value="relative">Relative</option>
                  <option value="absolute">Absolute</option>
                  <option value="fixed">Fixed</option>
                </select>
              </div>

              <div className="space-y-2">
                <label className="block text-sm font-medium text-gray-700">Width</label>
                <input
                  type="text"
                  value={styles[selectedContainer].width}
                  onChange={(e) => handleStyleChange(selectedContainer, 'width', e.target.value)}
                  className="w-full px-3 py-2 border rounded-md"
                  placeholder="e.g., 100%, 300px"
                />
              </div>

              <div className="space-y-2">
                <label className="block text-sm font-medium text-gray-700">Height</label>
                <input
                  type="text"
                  value={styles[selectedContainer].height}
                  onChange={(e) => handleStyleChange(selectedContainer, 'height', e.target.value)}
                  className="w-full px-3 py-2 border rounded-md"
                  placeholder="e.g., auto, 500px"
                />
              </div>

              <div className="space-y-2">
                <label className="block text-sm font-medium text-gray-700">Padding</label>
                <input
                  type="text"
                  value={styles[selectedContainer].padding}
                  onChange={(e) => handleStyleChange(selectedContainer, 'padding', e.target.value)}
                  className="w-full px-3 py-2 border rounded-md"
                  placeholder="e.g., 1rem, 16px"
                />
              </div>

              <div className="space-y-2">
                <label className="block text-sm font-medium text-gray-700">Margin</label>
                <input
                  type="text"
                  value={styles[selectedContainer].margin}
                  onChange={(e) => handleStyleChange(selectedContainer, 'margin', e.target.value)}
                  className="w-full px-3 py-2 border rounded-md"
                  placeholder="e.g., 1rem, 16px"
                />
              </div>

              <div className="space-y-2">
                <label className="block text-sm font-medium text-gray-700">Background Color</label>
                <input
                  type="color"
                  value={styles[selectedContainer].backgroundColor || '#ffffff'}
                  onChange={(e) => handleStyleChange(selectedContainer, 'backgroundColor', e.target.value)}
                  className="w-full h-10 px-1 py-1 border rounded-md"
                />
              </div>
            </div>
          )}
        </div>
      )}

      <div className={`${showGrid && isDevMode ? 'bg-gray-100' : ''} min-h-screen transition-all duration-200`}>
        {children}
      </div>
    </div>
  );
};