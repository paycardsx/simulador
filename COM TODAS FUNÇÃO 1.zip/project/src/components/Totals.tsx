import React from 'react';
import { DollarSign, TrendingUp } from 'lucide-react';
import { TotalsData } from '../types/types';

interface TotalsProps {
  totals: TotalsData;
}

export const Totals: React.FC<TotalsProps> = ({ totals }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
      <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg p-4 text-white">
        <div className="flex items-center space-x-2 mb-2">
          <DollarSign className="h-5 w-5" />
          <h3 className="font-semibold">Faturamento Total</h3>
        </div>
        <p className="text-2xl font-bold">{totals.faturamentoTotal}</p>
      </div>
      
      <div className="bg-gradient-to-br from-green-500 to-green-600 rounded-lg p-4 text-white">
        <div className="flex items-center space-x-2 mb-2">
          <TrendingUp className="h-5 w-5" />
          <h3 className="font-semibold">Lucro Total</h3>
        </div>
        <p className="text-2xl font-bold">{totals.lucroTotal}</p>
      </div>
    </div>
  );
};