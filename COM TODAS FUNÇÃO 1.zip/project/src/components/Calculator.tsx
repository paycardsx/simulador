import React, { useState, useEffect, useRef } from 'react';
import { Calculator as CalculatorIcon, Download } from 'lucide-react';
import { CalculationResult } from '../types/types';
import html2canvas from 'html2canvas';

interface CalculatorProps {
  modoCobrar: boolean;
  acessoLiberado: boolean;
  onCalculate: (valor: number, parcelas: number) => CalculationResult | null;
  onRegistrar: (resultado: CalculationResult) => void;
}

export const Calculator: React.FC<CalculatorProps> = ({
  modoCobrar,
  acessoLiberado,
  onCalculate,
  onRegistrar
}) => {
  const [valor, setValor] = useState('5.000,00');
  const [parcelas, setParcelas] = useState('12');
  const [resultado, setResultado] = useState<CalculationResult | null>(null);
  const [hasCalculated, setHasCalculated] = useState(false);
  const calculatorRef = useRef<HTMLDivElement>(null);

  const formatarValor = (input: string) => {
    const numero = input.replace(/\D/g, '');
    const valorFormatado = (Number(numero) / 100).toFixed(2);
    return valorFormatado.replace('.', ',').replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');
  };

  const handleValorChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setValor(formatarValor(e.target.value));
  };

  const calcular = () => {
    const valorNumerico = parseFloat(valor.replace(/\./g, '').replace(',', '.'));
    const parcelasNumerico = parseInt(parcelas);
    const result = onCalculate(valorNumerico, parcelasNumerico);
    setResultado(result);
    setHasCalculated(true);
  };

  useEffect(() => {
    if (hasCalculated) {
      calcular();
    }
  }, [modoCobrar]);

  const exportToImage = async () => {
    if (!calculatorRef.current || !resultado) return;

    try {
      const canvas = await html2canvas(calculatorRef.current, {
        backgroundColor: '#ffffff',
        scale: 2,
        logging: false,
        useCORS: true
      });

      const image = canvas.toDataURL('image/jpeg', 0.9);
      const link = document.createElement('a');
      link.href = image;
      link.download = `calculo-financeiro-${new Date().toISOString().split('T')[0]}.jpg`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (error) {
      console.error('Error exporting image:', error);
    }
  };

  return (
    <div ref={calculatorRef} className="bg-white rounded-lg shadow-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-2">
          <CalculatorIcon className="h-6 w-6 text-blue-600" />
          <h2 className="text-2xl font-bold text-gray-800">Calculadora Financeira</h2>
        </div>
        {resultado && (
          <button
            onClick={exportToImage}
            className="flex items-center space-x-2 px-4 py-2 bg-gray-100 text-gray-700 rounded-md hover:bg-gray-200 transition-colors"
          >
            <Download size={20} />
            <span>Exportar Imagem</span>
          </button>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Valor a {modoCobrar ? "cobrar" : "receber"}
          </label>
          <div className="relative">
            <span className="absolute left-3 top-2 text-gray-500">R$</span>
            <input
              type="text"
              value={valor}
              onChange={handleValorChange}
              className="block w-full pl-10 pr-3 py-2 rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Parcelamento
          </label>
          <select
            value={parcelas}
            onChange={(e) => setParcelas(e.target.value)}
            className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          >
            {[...Array(18)].map((_, i) => (
              <option key={i + 1} value={i + 1}>{i + 1}x</option>
            ))}
          </select>
        </div>
      </div>

      <div className="flex space-x-4 mb-6">
        <button
          onClick={calcular}
          className="flex-1 bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
        >
          Calcular
        </button>
        {resultado && acessoLiberado && (
          <button
            onClick={() => onRegistrar(resultado)}
            className="flex-1 bg-green-600 text-white py-2 px-4 rounded-md hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2"
          >
            Registrar
          </button>
        )}
      </div>

      {resultado && (
        <div className="bg-gray-50 rounded-lg p-4 space-y-2">
          <h3 className="font-semibold text-lg text-gray-800 mb-3">Resultado da Simulação</h3>
          
          <div className="grid grid-cols-2 gap-2">
            <div className="text-sm text-gray-600">Parcelamento:</div>
            <div className="text-sm font-medium">{resultado.parcelamento}x</div>
            
            <div className="text-sm text-gray-600">Taxa aplicada:</div>
            <div className="text-sm font-medium">{resultado.taxaAplicada}%</div>
            
            {acessoLiberado && (
              <>
                <div className="text-sm text-gray-600">Taxa de custo:</div>
                <div className="text-sm font-medium">{resultado.taxaDeCusto}%</div>
                
                <div className="text-sm text-gray-600">Lucro:</div>
                <div className="text-sm font-medium text-green-600">{resultado.lucro}</div>
              </>
            )}
            
            <div className="text-sm text-gray-600">Valor da Parcela:</div>
            <div className="text-sm font-medium text-green-600">
              {resultado.valorParcela} {resultado.parcelamento > 1 ? `(${resultado.parcelamento}x)` : ''}
            </div>
            
            <div className="text-sm text-gray-600">
              Valor que deseja {modoCobrar ? "cobrar" : "receber"}:
            </div>
            <div className="text-sm font-medium">{resultado.valorReceber}</div>
            
            <div className="text-sm text-gray-600">Juros:</div>
            <div className="text-sm font-medium text-red-600">{resultado.juros}</div>
            
            <div className="text-sm text-gray-600">
              Valor a {modoCobrar ? "receber" : "passar na maquininha"}:
            </div>
            <div className="text-sm font-medium text-green-600">{resultado.valorPassar}</div>
          </div>
        </div>
      )}
    </div>
  );
};