import React from 'react';
import { DollarSign, TrendingUp, ArrowUpCircle, ArrowDownCircle } from 'lucide-react';
import { SimulationRecord } from '../types/types';

interface SalesSummaryProps {
  historico: SimulationRecord[];
}

export const SalesSummary: React.FC<SalesSummaryProps> = ({ historico }) => {
  const calcularTotais = () => {
    return historico.reduce((acc, item) => {
      const lucro = parseFloat(item.lucro.replace(/[R$\s.]/g, '').replace(',', '.'));
      const valorOperacao = item.tipo === 'receber' 
        ? parseFloat(item.valorPassar.replace(/[R$\s.]/g, '').replace(',', '.'))
        : parseFloat(item.valorReceber.replace(/[R$\s.]/g, '').replace(',', '.'));
      
      if (item.tipo === 'cobrar') {
        acc.totalCobrado += valorOperacao;
        acc.lucroCobrado += lucro;
      } else {
        acc.totalRecebido += valorOperacao;
        acc.lucroRecebido += lucro;
      }
      
      return acc;
    }, { 
      totalCobrado: 0, 
      totalRecebido: 0, 
      lucroCobrado: 0, 
      lucroRecebido: 0 
    });
  };

  const totais = calcularTotais();
  const formatCurrency = (value: number) => 
    value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

  return (
    <div className="bg-white rounded-lg shadow-md p-6 mb-6">
      <h2 className="text-xl font-bold text-gray-800 mb-4">Resumo de Operações</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-4">
          <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg p-4 text-white">
            <div className="flex items-center space-x-2 mb-2">
              <ArrowUpCircle className="h-5 w-5" />
              <h3 className="font-semibold">Total Cobrado</h3>
            </div>
            <p className="text-2xl font-bold">{formatCurrency(totais.totalCobrado)}</p>
            <p className="text-sm opacity-80">
              Lucro: {formatCurrency(totais.lucroCobrado)}
            </p>
          </div>
          
          <div className="bg-gradient-to-br from-green-500 to-green-600 rounded-lg p-4 text-white">
            <div className="flex items-center space-x-2 mb-2">
              <ArrowDownCircle className="h-5 w-5" />
              <h3 className="font-semibold">Total Recebido</h3>
            </div>
            <p className="text-2xl font-bold">{formatCurrency(totais.totalRecebido)}</p>
            <p className="text-sm opacity-80">
              Lucro: {formatCurrency(totais.lucroRecebido)}
            </p>
          </div>
        </div>

        <div className="space-y-4">
          <div className="bg-gradient-to-br from-purple-500 to-purple-600 rounded-lg p-4 text-white">
            <div className="flex items-center space-x-2 mb-2">
              <DollarSign className="h-5 w-5" />
              <h3 className="font-semibold">Movimentação Total</h3>
            </div>
            <p className="text-2xl font-bold">
              {formatCurrency(totais.totalCobrado + totais.totalRecebido)}
            </p>
          </div>
          
          <div className="bg-gradient-to-br from-indigo-500 to-indigo-600 rounded-lg p-4 text-white">
            <div className="flex items-center space-x-2 mb-2">
              <TrendingUp className="h-5 w-5" />
              <h3 className="font-semibold">Lucro Total</h3>
            </div>
            <p className="text-2xl font-bold">
              {formatCurrency(totais.lucroCobrado + totais.lucroRecebido)}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};