export interface SimulationRecord {
  id: string;
  data: string;
  parcelamento: string;
  taxaAplicada: string;
  taxaDeCusto: string;
  lucro: string;
  valorParcela: string;
  valorReceber: string;
  valorPassar: string;
  juros: string;
  valorPrincipal: string;
  tipo: 'cobrar' | 'receber';
}

export interface CalculationResult {
  parcelamento: number;
  taxaAplicada: number;
  taxaDeCusto: number;
  lucro: string;
  valorParcela: string;
  valorReceber: string;
  juros: string;
  valorPassar: string;
  bandeira: 'master-visa' | 'elo-hiper';
}

export interface TotalsData {
  lucroTotal: string;
  faturamentoTotal: string;
}