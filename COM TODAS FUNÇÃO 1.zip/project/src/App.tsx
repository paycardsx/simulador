import React, { useState } from 'react';
import { Calculator } from './components/Calculator';
import { LoginForm } from './components/LoginForm';
import { History } from './components/History';
import { TaxSettings } from './components/TaxSettings';
import { useFinancialCalculator } from './hooks/useFinancialCalculator';
import { Header } from './components/Header';
import { PublicCalculator } from './components/PublicCalculator';
import { DeveloperMode } from './components/DeveloperMode';

function App() {
  const [isPublicView] = useState(() => window.location.pathname === '/public');
  const [showSettings, setShowSettings] = useState(false);
  const {
    modoCobrar,
    setModoCobrar,
    acessoLiberado,
    historico,
    deletedItems,
    taxas,
    taxasDeCusto,
    calcular,
    registrarSimulacao,
    removerItem,
    desfazerExclusao,
    login,
    logout,
    atualizarTaxas
  } = useFinancialCalculator();

  if (isPublicView) {
    return <PublicCalculator calcular={calcular} taxas={taxas} />;
  }

  const MainContent = () => (
    <div className="min-h-screen bg-gray-100 p-4 md:p-8">
      <div className="max-w-6xl mx-auto space-y-8">
        <Header 
          modoCobrar={modoCobrar}
          setModoCobrar={setModoCobrar}
          acessoLiberado={acessoLiberado}
          onLogout={logout}
          historico={historico}
          onToggleSettings={() => setShowSettings(!showSettings)}
          showSettings={showSettings}
        />

        {acessoLiberado && showSettings ? (
          <TaxSettings
            taxas={taxas}
            taxasDeCusto={taxasDeCusto}
            onSave={atualizarTaxas}
          />
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="space-y-8">
              {!acessoLiberado && (
                <div className="bg-white rounded-lg shadow-md p-6">
                  <h2 className="text-xl font-semibold text-gray-800 mb-4">Login</h2>
                  <LoginForm onLogin={login} />
                </div>
              )}
              
              <div id="calculator-container">
                <Calculator
                  modoCobrar={modoCobrar}
                  acessoLiberado={acessoLiberado}
                  onCalculate={calcular}
                  onRegistrar={registrarSimulacao}
                />
              </div>
            </div>

            {acessoLiberado && (
              <div id="history-container">
                <History
                  historico={historico}
                  deletedItems={deletedItems}
                  onRemoverItem={removerItem}
                  onDesfazerExclusao={desfazerExclusao}
                />
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );

  return acessoLiberado ? (
    <DeveloperMode containers={['calculator-container', 'history-container']}>
      <MainContent />
    </DeveloperMode>
  ) : (
    <MainContent />
  );
}

export default App;