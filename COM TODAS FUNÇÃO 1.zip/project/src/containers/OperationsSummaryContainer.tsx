import React, { useState, useMemo } from 'react';
import { SalesSummary } from '../components/SalesSummary';
import { DateFilter } from '../components/DateFilter';
import { SimulationRecord } from '../types/types';

type DateRange = 'today' | 'week' | '30days' | '90days' | 'all' | 'custom';

interface OperationsSummaryContainerProps {
  historico: SimulationRecord[];
}

export const OperationsSummaryContainer: React.FC<OperationsSummaryContainerProps> = ({ historico }) => {
  const [selectedRange, setSelectedRange] = useState<DateRange>('all');
  const [customDateRange, setCustomDateRange] = useState({
    start: new Date().toISOString().split('T')[0],
    end: new Date().toISOString().split('T')[0]
  });

  const filteredHistorico = useMemo(() => {
    if (historico.length === 0) return [];
    if (selectedRange === 'all') return historico;

    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const getDateFromString = (dateStr: string) => {
      const [day, month, year] = dateStr.split('/').map(Number);
      return new Date(year, month - 1, day);
    };

    return historico.filter(item => {
      const itemDate = getDateFromString(item.data);

      switch (selectedRange) {
        case 'today':
          return itemDate.getTime() === today.getTime();

        case 'week': {
          const weekAgo = new Date(today);
          weekAgo.setDate(weekAgo.getDate() - 7);
          return itemDate >= weekAgo;
        }

        case '30days': {
          const thirtyDaysAgo = new Date(today);
          thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
          return itemDate >= thirtyDaysAgo;
        }

        case '90days': {
          const ninetyDaysAgo = new Date(today);
          ninetyDaysAgo.setDate(ninetyDaysAgo.getDate() - 90);
          return itemDate >= ninetyDaysAgo;
        }

        case 'custom': {
          const start = new Date(customDateRange.start);
          const end = new Date(customDateRange.end);
          end.setHours(23, 59, 59, 999);
          return itemDate >= start && itemDate <= end;
        }

        default:
          return true;
      }
    });
  }, [historico, selectedRange, customDateRange]);

  if (historico.length === 0) return null;

  const handleCustomDateChange = (start: string, end: string) => {
    setCustomDateRange({ start, end });
  };
  
  return (
    <div className="sticky top-4 z-10">
      <DateFilter
        selectedRange={selectedRange}
        onRangeChange={setSelectedRange}
        customDateRange={customDateRange}
        onCustomDateChange={handleCustomDateChange}
      />
      <SalesSummary historico={filteredHistorico} />
    </div>
  );
};